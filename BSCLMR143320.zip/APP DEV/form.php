<html>
    <head>
        <title>Message</title>
    </head>
    <body>
        <?php
            $connect=mysqli_connect("localhost","root","","PHP");
            
            $first_name=mysqli_real_escape_string($connect, $_POST['first_name']);

            $last_name=mysqli_real_escape_string($connect, $_POST['last_name']);

            $phone_number=mysqli_real_escape_string($connect, $_POST['phone_number']);

            $email=mysqli_real_escape_string($connect, $_POST['email']);

            $country=mysqli_real_escape_string($connect, $_POST['country']);

            $gender=mysqli_real_escape_string($connect, $_POST['gender']);

            $date=mysqli_real_escape_string($connect, $_POST['date']);

            $postal_address=mysqli_real_escape_string($connect, $_POST['postal_address']);

            $postal_code=mysqli_real_escape_string($connect, $_POST['postal_code']);

            $education=mysqli_real_escape_string($connect, $_POST['education']);

            $religion=mysqli_real_escape_string($connect, $_POST['religion']);

            $course=mysqli_real_escape_string($connect, $_POST['course']);

            

            $table="INSERT INTO cookies(first_name, last_name, phone_number, email, country, gender, date, postal_address, postal_code, education, religion, course  )
            VALUES('$first_name','$last_name', '$phone_number',' $email', '$country', '$gender', ' $date', '$postal_address', '$postal_code', ' $education', '$religion','$course')";

            if(mysqli_query($connect,$table))
            {
                echo "Data Saved Successfully!";
            }
            else
            {
                echo "Data not saved!".mysqli_error($connect);
            }

            //Automatic sending mail
            $headers="From: bsclmr143320@spu.ac.ke";
            $subject="Successful form submission";
            $message="Dear $last_name $first_name, Your application has been successfully submitted for $course. Please await the outcome in two weeks time. Yours  Registrar";

            mail($email, $subject, $message, $headers);
        ?>
    </body>
</html>